<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Data lives in Lovable Cloud tables (categorias, negocios, productos, pedidos, pedido_items, profiles); historical orders remain readable, but new online orders are not offered.
- Commerce is a public catalog with direct WhatsApp contact instead of a cart or checkout, matching local buying habits.
- Negocio `imagen_url` may be a short key mapped to bundled photos in src/lib/images.ts.
- Administration uses a separate `user_roles` table and RLS `has_role` checks; UI visibility alone never grants privileges.
- Commerce photos live in private Storage with owner/admin upload policies and signed URLs for display, because workspace settings block public buckets.
- Sellers mark store coordinates through the Leaflet picker; product search uses product names already included in public store listings.
