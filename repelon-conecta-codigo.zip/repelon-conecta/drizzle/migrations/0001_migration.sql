alter table public.negocios add column latitud double precision, add column longitud double precision;
update public.negocios set latitud=10.4948, longitud=-75.1236 where slug='panaderia-la-espiga';
update public.negocios set latitud=10.4961, longitud=-75.1259 where slug='tienda-el-buen-vecino';
update public.negocios set latitud=10.4936, longitud=-75.1248 where slug='drogueria-salud-repelon';
update public.negocios set latitud=10.4919, longitud=-75.1219 where slug='ferreteria-el-martillo';
update public.negocios set latitud=10.5050, longitud=-75.1350 where slug='finca-don-efrain';
update public.negocios set latitud=10.4944, longitud=-75.1230 where slug='mandados-rapidos';