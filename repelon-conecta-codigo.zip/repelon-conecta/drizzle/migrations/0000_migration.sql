create table public.profiles (
  id uuid primary key,
  nombre text not null default '',
  telefono text,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile read" on public.profiles for select to authenticated using (id = auth.uid());
create policy "own profile insert" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "own profile update" on public.profiles for update to authenticated using (id = auth.uid());

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, nombre) values (new.id, coalesce(new.raw_user_meta_data->>'nombre', new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create table public.categorias (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  slug text not null unique,
  icono text,
  orden int not null default 0
);
grant select on public.categorias to anon, authenticated;
grant all on public.categorias to service_role;
alter table public.categorias enable row level security;
create policy "categorias public" on public.categorias for select using (true);

create table public.negocios (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid,
  categoria_id uuid references public.categorias(id) on delete set null,
  nombre text not null,
  slug text not null unique,
  descripcion text,
  direccion text not null default '',
  barrio text,
  telefono text,
  whatsapp text,
  horario text,
  imagen_url text,
  abierto boolean not null default true,
  destacado boolean not null default false,
  created_at timestamptz not null default now()
);
grant select on public.negocios to anon, authenticated;
grant insert, update, delete on public.negocios to authenticated;
grant all on public.negocios to service_role;
alter table public.negocios enable row level security;
create policy "negocios public" on public.negocios for select using (true);
create policy "owner insert negocio" on public.negocios for insert to authenticated with check (owner_id = auth.uid());
create policy "owner update negocio" on public.negocios for update to authenticated using (owner_id = auth.uid());
create policy "owner delete negocio" on public.negocios for delete to authenticated using (owner_id = auth.uid());

create table public.productos (
  id uuid primary key default gen_random_uuid(),
  negocio_id uuid not null references public.negocios(id) on delete cascade,
  nombre text not null,
  descripcion text,
  precio int not null default 0,
  imagen_url text,
  disponible boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.productos to anon, authenticated;
grant insert, update, delete on public.productos to authenticated;
grant all on public.productos to service_role;
alter table public.productos enable row level security;
create policy "productos public" on public.productos for select using (true);
create policy "owner manage productos" on public.productos for all to authenticated
  using (exists (select 1 from public.negocios n where n.id = negocio_id and n.owner_id = auth.uid()))
  with check (exists (select 1 from public.negocios n where n.id = negocio_id and n.owner_id = auth.uid()));

create table public.pedidos (
  id uuid primary key default gen_random_uuid(),
  numero serial,
  comprador_id uuid not null,
  negocio_id uuid not null references public.negocios(id) on delete cascade,
  estado text not null default 'RECIBIDO',
  metodo_entrega text not null default 'DOMICILIO',
  metodo_pago text not null default 'EFECTIVO',
  total int not null default 0,
  nombre text not null default '',
  telefono text,
  direccion text,
  barrio text,
  referencia text,
  notas text,
  created_at timestamptz not null default now()
);
grant select, update on public.pedidos to authenticated;
grant all on public.pedidos to service_role;
alter table public.pedidos enable row level security;
create policy "ver pedidos" on public.pedidos for select to authenticated using (
  comprador_id = auth.uid() or exists (select 1 from public.negocios n where n.id = negocio_id and n.owner_id = auth.uid()));
create policy "vendedor actualiza" on public.pedidos for update to authenticated using (
  exists (select 1 from public.negocios n where n.id = negocio_id and n.owner_id = auth.uid()));

create table public.pedido_items (
  id uuid primary key default gen_random_uuid(),
  pedido_id uuid not null references public.pedidos(id) on delete cascade,
  producto_id uuid references public.productos(id) on delete set null,
  nombre text not null,
  precio int not null,
  cantidad int not null
);
grant select on public.pedido_items to authenticated;
grant all on public.pedido_items to service_role;
alter table public.pedido_items enable row level security;
create policy "ver items" on public.pedido_items for select to authenticated using (
  exists (select 1 from public.pedidos p where p.id = pedido_id and (p.comprador_id = auth.uid()
    or exists (select 1 from public.negocios n where n.id = p.negocio_id and n.owner_id = auth.uid()))));

create or replace function public.crear_pedido(
  _negocio_id uuid, _items jsonb, _metodo_entrega text, _metodo_pago text,
  _nombre text, _telefono text, _direccion text, _barrio text, _referencia text, _notas text
) returns uuid language plpgsql security definer set search_path = public as $$
declare _id uuid; _total int := 0; it jsonb; p record; q int;
begin
  if auth.uid() is null then raise exception 'Debes iniciar sesión'; end if;
  if jsonb_array_length(_items) = 0 then raise exception 'El carrito está vacío'; end if;
  insert into pedidos (comprador_id, negocio_id, metodo_entrega, metodo_pago, nombre, telefono, direccion, barrio, referencia, notas)
  values (auth.uid(), _negocio_id, _metodo_entrega, _metodo_pago, _nombre, _telefono, _direccion, _barrio, _referencia, _notas)
  returning id into _id;
  for it in select * from jsonb_array_elements(_items) loop
    select * into p from productos where id = (it->>'producto_id')::uuid and negocio_id = _negocio_id and disponible;
    if not found then raise exception 'Producto no disponible'; end if;
    q := greatest(1, least(99, (it->>'cantidad')::int));
    insert into pedido_items (pedido_id, producto_id, nombre, precio, cantidad) values (_id, p.id, p.nombre, p.precio, q);
    _total := _total + p.precio * q;
  end loop;
  update pedidos set total = _total where id = _id;
  return _id;
end $$;
grant execute on function public.crear_pedido to authenticated;

insert into public.categorias (nombre, slug, icono, orden) values
('Comida','comida','🥖',1),('Bebidas','bebidas','🥤',2),('Droguería','drogueria','💊',3),
('Ferretería','ferreteria','🔧',4),('Aseo','aseo','🧼',5),('Campo','campo','🌽',6),('Servicios','servicios','🛵',7);

insert into public.negocios (categoria_id, nombre, slug, descripcion, direccion, barrio, whatsapp, horario, imagen_url, abierto, destacado) values
((select id from categorias where slug='comida'),'Panadería La Espiga','panaderia-la-espiga','Pan casero todos los días desde las 5 de la mañana. Pasteles y tortas por encargo.','Calle 8 # 5-23','Centro','573001111001','5:00 a.m. – 8:00 p.m.','panaderia',true,true),
((select id from categorias where slug='comida'),'Tienda El Buen Vecino','tienda-el-buen-vecino','La tienda del barrio: granos, aseo, bebidas y lo que necesites para la casa.','Carrera 12 # 4-05','El Carmen','573001111002','6:00 a.m. – 10:00 p.m.','tienda',true,true),
((select id from categorias where slug='drogueria'),'Droguería Salud Repelón','drogueria-salud-repelon','Medicamentos, cuidado personal y atención amable. Domicilios en el casco urbano.','Calle 10 # 7-40','Centro','573001111003','7:00 a.m. – 9:00 p.m.','drogueria',true,false),
((select id from categorias where slug='ferreteria'),'Ferretería El Martillo','ferreteria-el-martillo','Herramientas, plomería, electricidad y pinturas para tu obra.','Carrera 9 # 11-15','Barrio Nuevo','573001111004','7:00 a.m. – 6:00 p.m.','ferreteria',true,false),
((select id from categorias where slug='campo'),'Finca Don Efraín','finca-don-efrain','Productos frescos del campo de Repelón: yuca, plátano, ñame, huevos criollos y queso costeño.','Vereda Rotinet','Rotinet','573001111005','6:00 a.m. – 2:00 p.m.','campo',true,true),
((select id from categorias where slug='servicios'),'Mototaxi y Mandados Rápidos','mandados-rapidos','Hacemos tus mandados y llevamos encargos a cualquier punto del pueblo.','Plaza principal','Centro','573001111006','6:00 a.m. – 9:00 p.m.','servicios',false,false);

insert into public.productos (negocio_id, nombre, descripcion, precio) values
((select id from negocios where slug='panaderia-la-espiga'),'Pan de queso (x5)','Recién horneado, bolsa de 5 unidades.',4000),
((select id from negocios where slug='panaderia-la-espiga'),'Pan blandito (x10)','Pan blanco suave para el desayuno.',5000),
((select id from negocios where slug='panaderia-la-espiga'),'Arepa de huevo','Crujiente, rellena de huevo y carne.',4000),
((select id from negocios where slug='panaderia-la-espiga'),'Torta de chocolate (1 lb)','Por encargo con un día de anticipación.',18000),
((select id from negocios where slug='tienda-el-buen-vecino'),'Arroz Diana 500 g',null,3200),
((select id from negocios where slug='tienda-el-buen-vecino'),'Aceite 1 L',null,9500),
((select id from negocios where slug='tienda-el-buen-vecino'),'Panela (x4 tapas)',null,4000),
((select id from negocios where slug='tienda-el-buen-vecino'),'Gaseosa 1.5 L',null,6500),
((select id from negocios where slug='tienda-el-buen-vecino'),'Jabón Rey',null,3800),
((select id from negocios where slug='drogueria-salud-repelon'),'Acetaminofén 500 mg (x10)',null,3000),
((select id from negocios where slug='drogueria-salud-repelon'),'Suero oral',null,4500),
((select id from negocios where slug='drogueria-salud-repelon'),'Protector solar 60 ml',null,22000),
((select id from negocios where slug='ferreteria-el-martillo'),'Martillo de uña',null,25000),
((select id from negocios where slug='ferreteria-el-martillo'),'Tubo PVC ½" (3 m)',null,12000),
((select id from negocios where slug='ferreteria-el-martillo'),'Bombillo LED 12 W',null,7000),
((select id from negocios where slug='finca-don-efrain'),'Yuca (2 kg)','Recién arrancada.',5000),
((select id from negocios where slug='finca-don-efrain'),'Plátano verde (racimo pequeño)',null,8000),
((select id from negocios where slug='finca-don-efrain'),'Huevos criollos (x12)',null,12000),
((select id from negocios where slug='finca-don-efrain'),'Queso costeño (1 lb)',null,11000),
((select id from negocios where slug='mandados-rapidos'),'Mandado en el casco urbano','Llevamos o traemos lo que necesites.',3000),
((select id from negocios where slug='mandados-rapidos'),'Viaje a vereda cercana',null,8000);
