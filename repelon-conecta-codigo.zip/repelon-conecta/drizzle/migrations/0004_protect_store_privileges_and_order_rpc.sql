CREATE OR REPLACE FUNCTION public.protect_order_details() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF current_user = 'postgres' THEN RETURN NEW; END IF;
  IF (NEW.comprador_id, NEW.negocio_id, NEW.numero, NEW.metodo_entrega, NEW.metodo_pago, NEW.total, NEW.nombre, NEW.telefono, NEW.direccion, NEW.barrio, NEW.referencia, NEW.notas, NEW.created_at) IS DISTINCT FROM (OLD.comprador_id, OLD.negocio_id, OLD.numero, OLD.metodo_entrega, OLD.metodo_pago, OLD.total, OLD.nombre, OLD.telefono, OLD.direccion, OLD.barrio, OLD.referencia, OLD.notas, OLD.created_at) THEN
    RAISE EXCEPTION 'Solo se puede cambiar el estado del pedido';
  END IF;
  IF NEW.estado NOT IN ('RECIBIDO', 'PREPARANDO', 'EN_CAMINO', 'ENTREGADO', 'CANCELADO') THEN RAISE EXCEPTION 'Estado inválido'; END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.protect_business_admin_fields() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    IF TG_OP = 'INSERT' AND NEW.destacado THEN RAISE EXCEPTION 'Solo administración puede destacar negocios'; END IF;
    IF TG_OP = 'UPDATE' AND (NEW.owner_id IS DISTINCT FROM OLD.owner_id OR NEW.destacado IS DISTINCT FROM OLD.destacado) THEN RAISE EXCEPTION 'Solo administración puede cambiar propietario o destacado'; END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER protect_business_admin_fields BEFORE INSERT OR UPDATE ON public.negocios FOR EACH ROW EXECUTE FUNCTION public.protect_business_admin_fields();