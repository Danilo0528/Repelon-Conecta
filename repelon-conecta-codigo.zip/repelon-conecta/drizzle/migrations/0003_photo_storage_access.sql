CREATE POLICY "published commerce photos readable" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'comercio-fotos');
CREATE POLICY "commerce photos upload" ON storage.objects FOR INSERT TO authenticated WITH CHECK (
  bucket_id = 'comercio-fotos' AND (
    public.has_role(auth.uid(), 'admin') OR EXISTS (
      SELECT 1 FROM public.negocios n WHERE n.id::text = (storage.foldername(name))[1] AND n.owner_id = auth.uid()
    )
  )
);
CREATE POLICY "commerce photos delete" ON storage.objects FOR DELETE TO authenticated USING (
  bucket_id = 'comercio-fotos' AND (
    public.has_role(auth.uid(), 'admin') OR EXISTS (
      SELECT 1 FROM public.negocios n WHERE n.id::text = (storage.foldername(name))[1] AND n.owner_id = auth.uid()
    )
  )
);