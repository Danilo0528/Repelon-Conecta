CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own roles" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;
CREATE POLICY "admin manages businesses" ON public.negocios FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin manages products" ON public.productos FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin reads orders" ON public.pedidos FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin updates orders" ON public.pedidos FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin reads order items" ON public.pedido_items FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE OR REPLACE FUNCTION public.protect_order_details() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF (NEW.comprador_id, NEW.negocio_id, NEW.numero, NEW.metodo_entrega, NEW.metodo_pago, NEW.total, NEW.nombre, NEW.telefono, NEW.direccion, NEW.barrio, NEW.referencia, NEW.notas, NEW.created_at) IS DISTINCT FROM (OLD.comprador_id, OLD.negocio_id, OLD.numero, OLD.metodo_entrega, OLD.metodo_pago, OLD.total, OLD.nombre, OLD.telefono, OLD.direccion, OLD.barrio, OLD.referencia, OLD.notas, OLD.created_at) THEN
    RAISE EXCEPTION 'Solo se puede cambiar el estado del pedido';
  END IF;
  IF NEW.estado NOT IN ('RECIBIDO', 'PREPARANDO', 'EN_CAMINO', 'ENTREGADO', 'CANCELADO') THEN RAISE EXCEPTION 'Estado inválido'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER protect_order_details BEFORE UPDATE ON public.pedidos FOR EACH ROW EXECUTE FUNCTION public.protect_order_details();