import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const categoriasQuery = queryOptions({
  queryKey: ["categorias"],
  queryFn: async () => {
    const { data, error } = await supabase.from("categorias").select("*").order("orden");
    if (error) throw error;
    return data;
  },
});

async function fetchNegocios() {
    const { data, error } = await supabase
      .from("negocios")
      .select("*, categorias(nombre, slug, icono), productos(nombre)")
      .order("destacado", { ascending: false })
      .order("nombre");
    if (error) throw error;
    return data;
}
export const negociosQuery = queryOptions({ queryKey: ["negocios"], queryFn: fetchNegocios });
export type NegocioListItem = Awaited<ReturnType<typeof fetchNegocios>>[number];

export const negocioQuery = (slug: string) =>
  queryOptions({
    queryKey: ["negocio", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("negocios")
        .select("*, categorias(nombre, slug, icono), productos(*)")
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });
