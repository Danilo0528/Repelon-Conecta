export const cop = (n: number) =>
  "$" + Math.round(n).toLocaleString("es-CO", { maximumFractionDigits: 0 });

export const ESTADOS: Record<string, { label: string; tone: string }> = {
  RECIBIDO: { label: "Pedido recibido", tone: "bg-cielo/15 text-ink" },
  PREPARANDO: { label: "En preparación", tone: "bg-cielo/25 text-ink" },
  EN_CAMINO: { label: "En camino", tone: "bg-leaf/15 text-leaf" },
  ENTREGADO: { label: "Entregado", tone: "bg-leaf text-primary-foreground" },
  CANCELADO: { label: "Cancelado", tone: "bg-destructive/10 text-destructive" },
};

export const PAGOS: Record<string, string> = {
  EFECTIVO: "Efectivo contra entrega",
  NEQUI: "Nequi",
  DAVIPLATA: "Daviplata",
  TRANSFERENCIA: "Transferencia bancaria",
};

export const slugify = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");

export const estado = (k: string) => ESTADOS[k] ?? { label: "Pedido recibido", tone: "bg-cielo/15 text-ink" };
