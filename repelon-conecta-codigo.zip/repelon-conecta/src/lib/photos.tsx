import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const BUCKET = "comercio-fotos";

export function usePhotoUrl(value: string | null | undefined) {
  return useQuery({
    queryKey: ["photo-url", value],
    enabled: Boolean(value?.startsWith("photo:")),
    staleTime: 45 * 60 * 1000,
    queryFn: async () => {
      const path = value?.slice(6);
      if (!path) return null;
      const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(path, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
  }).data;
}

export async function uploadPhoto(file: File, negocioId: string) {
  if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) throw new Error("Elige una imagen de máximo 5 MB.");
  const extension = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  const path = `${negocioId}/${crypto.randomUUID()}.${extension}`;
  const { error } = await supabase.storage.from(BUCKET).upload(path, file, { contentType: file.type });
  if (error) throw error;
  return `photo:${path}`;
}

export function CommercePhoto({ value, fallback, alt, className }: { value: string | null | undefined; fallback: string; alt: string; className?: string }) {
  const signed = usePhotoUrl(value);
  return <img src={value?.startsWith("photo:") ? signed ?? fallback : value?.startsWith("http") ? value : fallback} alt={alt} className={className} loading="lazy" />;
}