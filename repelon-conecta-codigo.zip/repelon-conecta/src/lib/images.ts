import panaderia from "@/assets/panaderia.jpg";
import tienda from "@/assets/tienda.jpg";
import drogueria from "@/assets/drogueria.jpg";
import ferreteria from "@/assets/ferreteria.jpg";
import campo from "@/assets/campo.jpg";
import servicios from "@/assets/servicios.jpg";

const byKey: Record<string, string> = {
  panaderia,
  tienda,
  comida: tienda,
  bebidas: tienda,
  aseo: tienda,
  drogueria,
  ferreteria,
  campo,
  servicios,
};

/** Negocios store either a full URL or a short key (e.g. "panaderia"). */
export function negocioImg(imagen: string | null | undefined, categoriaSlug?: string | null) {
  if (imagen && /^https?:\/\//.test(imagen)) return imagen;
  if (imagen && byKey[imagen]) return byKey[imagen];
  if (categoriaSlug && byKey[categoriaSlug]) return byKey[categoriaSlug];
  return tienda;
}
