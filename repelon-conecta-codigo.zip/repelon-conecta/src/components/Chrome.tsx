import { Link } from "@tanstack/react-router";
import { Home, Store, User } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export function Blobs() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="animate-drift absolute -left-32 -top-36 size-[520px] rounded-full bg-blob-1 opacity-60 blur-[60px]" />
      <div className="animate-drift absolute -right-36 top-32 size-[460px] rounded-full bg-blob-2 opacity-60 blur-[60px] [animation-direction:reverse]" />
      <div className="animate-drift absolute -bottom-44 left-1/4 size-[560px] rounded-full bg-blob-3 opacity-60 blur-[60px]" />
    </div>
  );
}

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2">
      <div className="grid size-9 place-items-center rounded-xl bg-leaf font-display text-lg font-semibold text-primary-foreground">
        R
      </div>
      <div className="leading-tight">
        <p className="font-display text-lg font-semibold tracking-tight text-ink">Repelón Conecta</p>
        <p className="text-xs font-semibold uppercase text-leaf">del pueblo, para el pueblo</p>
      </div>
    </Link>
  );
}

const navLink = "text-muted-foreground hover:text-leaf transition-colors";
const navActive = { className: "text-ink" };

export function SiteHeader() {
  const { user } = useAuth();
  const { data: isAdmin } = useQuery({ queryKey: ["admin-nav", user?.id], enabled: Boolean(user), queryFn: async () => { const { data } = await supabase.from("user_roles").select("role").eq("user_id", user?.id ?? "").eq("role", "admin").maybeSingle(); return data?.role === "admin"; } });
  return (
    <header className="sticky top-0 z-50 mx-auto max-w-6xl px-4 pt-4">
      <nav className="glass flex items-center gap-3 rounded-2xl px-4 py-3">
        <Logo />
        <div className="ml-4 hidden items-center gap-6 text-sm font-medium md:flex">
          <Link to="/negocios" className={navLink} activeProps={navActive}>
            Comercios
          </Link>
          <Link to="/vendedor" className={navLink} activeProps={navActive}>
            Mi negocio
          </Link>
          {isAdmin && <Link to="/admin" className={navLink} activeProps={navActive}>Administración</Link>}
        </div>
        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <Link to="/perfil" className="glass-soft hidden size-10 place-items-center rounded-xl text-ink sm:grid" aria-label="Perfil">
              <User className="size-4" />
            </Link>
          ) : (
            <Button asChild variant="glass" className="hidden sm:inline-flex">
              <Link to="/entrar">Entrar</Link>
            </Button>
          )}
          <Button asChild className="hidden md:inline-flex">
            <Link to="/vendedor">Vender aquí</Link>
          </Button>
        </div>
      </nav>
    </header>
  );
}

export function BottomNav() {
  const items = [
    { to: "/", label: "Inicio", Icon: Home },
    { to: "/negocios", label: "Negocios", Icon: Store },
    { to: "/vendedor", label: "Mi negocio", Icon: Store },
    { to: "/perfil", label: "Perfil", Icon: User },
  ] as const;
  return (
    <nav className="fixed inset-x-3 bottom-3 z-50 md:hidden">
      <div className="glass grid grid-cols-4 rounded-2xl px-1 py-1.5">
        {items.map(({ to, label, Icon }) => (
          <Link
            key={to}
            to={to}
            activeOptions={{ exact: to === "/" }}
            className="relative flex flex-col items-center gap-0.5 py-1 text-xs font-medium text-muted-foreground"
            activeProps={{ className: "text-leaf font-bold" }}
          >
            <Icon className="size-5" />
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
}

export function SiteFooter() {
  return (
    <footer className="glass-soft relative z-10 mt-10 border-x-0 border-b-0 py-6 pb-28 md:pb-6">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 text-xs text-muted-foreground md:flex-row">
        <span>© 2026 Repelón Conecta · Hecho para la comunidad</span>
        <span className="font-semibold text-leaf">Repelón · Atlántico · Colombia</span>
      </div>
    </footer>
  );
}

export function Abierto({ abierto }: { abierto: boolean }) {
  return abierto ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-leaf/10 px-2.5 py-1 text-sm font-semibold text-leaf">
      <span className="size-1.5 rounded-full bg-leaf" /> Abierto
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-sm font-semibold text-muted-foreground">
      <span className="size-1.5 rounded-full bg-muted-foreground" /> Cerrado
    </span>
  );
}

export function PageTitle({ title, subtitle }: { title: string; subtitle?: string | undefined }) {
  return (
    <div className="mb-6">
      <h1 className="font-display text-3xl font-semibold tracking-tight text-ink md:text-4xl">{title}</h1>
      {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
    </div>
  );
}
