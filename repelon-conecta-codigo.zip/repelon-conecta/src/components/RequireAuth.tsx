import { Link, useLocation } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

export function RequireAuth({ children, mensaje }: { children: ReactNode; mensaje: string }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <div className="mx-auto max-w-6xl px-4 py-10"><div className="glass h-60 animate-pulse rounded-3xl" /></div>;
  if (!user)
    return (
      <section className="mx-auto max-w-md px-4 py-16">
        <div className="glass rounded-3xl p-8 text-center">
          <h1 className="text-2xl font-semibold text-ink">Inicia sesión</h1>
          <p className="mt-2 text-sm text-muted-foreground">{mensaje}</p>
          <Button asChild className="mt-6"><Link to="/entrar" search={{ next: loc.pathname }}>Entrar o crear cuenta</Link></Button>
        </div>
      </section>
    );
  return <>{children}</>;
}
