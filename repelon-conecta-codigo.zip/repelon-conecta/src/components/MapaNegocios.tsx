import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import type { Map as LMap, Marker } from "leaflet";

export type PuntoMapa = { id: string; nombre: string; latitud: number | null; longitud: number | null; abierto: boolean; icono?: string | null };

const CENTRO: [number, number] = [10.4948, -75.1245];

/** Leaflet + OpenStreetMap. Leaflet touches `window`, so it is imported inside the effect. */
export function MapaNegocios({
  puntos,
  seleccionadoId,
  onSeleccionar,
  zoom = 15,
  className,
}: {
  puntos: PuntoMapa[];
  seleccionadoId?: string | null;
  onSeleccionar?: (id: string) => void;
  zoom?: number;
  className?: string;
}) {
  const el = useRef<HTMLDivElement>(null);
  const map = useRef<LMap | null>(null);
  const markers = useRef<Marker[]>([]);
  const L = useRef<typeof import("leaflet") | null>(null);
  const cb = useRef(onSeleccionar);
  cb.current = onSeleccionar;

  useEffect(() => {
    let cancel = false;
    import("leaflet").then((mod) => {
      if (cancel || !el.current || map.current) return;
      L.current = mod.default ?? mod;
      map.current = L.current.map(el.current, { zoomControl: false, scrollWheelZoom: false, attributionControl: true }).setView(CENTRO, zoom);
      L.current.control.zoom({ position: "bottomright" }).addTo(map.current);
      L.current
        .tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; OpenStreetMap',
          maxZoom: 19,
        })
        .addTo(map.current);
      dibujar();
    });
    return () => {
      cancel = true;
      map.current?.remove();
      map.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function dibujar() {
    const Lf = L.current;
    const m = map.current;
    if (!Lf || !m) return;
    markers.current.forEach((mk) => mk.remove());
    const conPunto = puntos.filter((p) => p.latitud != null && p.longitud != null);
    markers.current = conPunto.map((p) => {
      const sel = p.id === seleccionadoId;
      const icon = Lf.divIcon({
        className: "",
        html: `<div class="pin ${p.abierto ? "pin-abierto" : "pin-cerrado"} ${sel ? "pin-sel" : ""}"><span>${p.icono ?? "●"}</span></div>`,
        iconSize: [40, 48],
        iconAnchor: [20, 46],
      });
      const mk = Lf.marker([p.latitud!, p.longitud!], { icon, title: p.nombre }).addTo(m);
      mk.on("click", () => cb.current?.(p.id));
      return mk;
    });
    const sel = conPunto.find((p) => p.id === seleccionadoId);
    if (sel) m.flyTo([sel.latitud!, sel.longitud!], Math.max(m.getZoom(), 16), { duration: 0.6 });
    else if (conPunto.length > 1) m.fitBounds(Lf.latLngBounds(conPunto.map((p) => [p.latitud!, p.longitud!])), { padding: [50, 50], maxZoom: 16 });
  }

  useEffect(dibujar, [puntos, seleccionadoId]);

  return <div ref={el} className={className} />;
}
