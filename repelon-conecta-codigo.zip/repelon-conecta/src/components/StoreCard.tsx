import { Link } from "@tanstack/react-router";
import { Star, MessageCircle } from "lucide-react";
import { Abierto } from "@/components/Chrome";
import { negocioImg } from "@/lib/images";
import { CommercePhoto } from "@/lib/photos";
import type { NegocioListItem } from "@/lib/queries";

export function StoreCard({ n }: { n: NegocioListItem }) {
  const count = n.productos?.length ?? 0;
  return (
    <article className="glass group rounded-lg p-4 transition-transform hover:-translate-y-1">
      <Link to="/negocios/$slug" params={{ slug: n.slug }} className="block">
      <div className="overflow-hidden rounded-2xl">
        <CommercePhoto value={n.imagen_url} fallback={negocioImg(null, n.categorias?.slug)} alt={n.nombre} className="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-105" />
      </div>
      <div className="flex items-center justify-between pt-4">
        <h3 className="font-display text-lg font-semibold text-ink">{n.nombre}</h3>
        {n.destacado && (
          <span className="inline-flex items-center gap-1 text-xs font-semibold text-azul">
            <Star className="size-3 fill-current" /> Destacado
          </span>
        )}
      </div>
      <p className="mt-1 line-clamp-1 text-sm text-muted-foreground">{n.descripcion}</p>
      <div className="mt-3 flex items-center gap-2">
        <Abierto abierto={n.abierto} />
        <span className="text-sm text-muted-foreground">
          {n.barrio ?? n.direccion} · {count} productos
        </span>
      </div>
      </Link>
      {n.whatsapp && <a href={`https://wa.me/${n.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-leaf hover:underline"><MessageCircle className="size-4" /> Pedir por WhatsApp</a>}
    </article>
  );
}
