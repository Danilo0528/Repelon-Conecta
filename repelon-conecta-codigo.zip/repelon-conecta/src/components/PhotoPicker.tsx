import { useState } from "react";
import { ImagePlus } from "lucide-react";
import { toast } from "sonner";
import { uploadPhoto } from "@/lib/photos";
import { Button } from "@/components/ui/button";

export function PhotoPicker({ negocioId, onUploaded, label = "Subir foto" }: { negocioId: string; onUploaded: (path: string) => void; label?: string }) {
  const [busy, setBusy] = useState(false);
  return <span className="inline-flex items-center">
    <Button type="button" variant="outline" disabled={busy} onClick={(e) => (e.currentTarget.nextElementSibling as HTMLInputElement | null)?.click()}><ImagePlus />{busy ? "Subiendo…" : label}</Button>
    <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" tabIndex={-1} disabled={busy} onChange={async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setBusy(true);
      try { onUploaded(await uploadPhoto(file, negocioId)); toast.success("Foto subida"); }
      catch (error) { toast.error(error instanceof Error ? error.message : "No se pudo subir la foto"); }
      finally { setBusy(false); e.target.value = ""; }
    }} />
  </span>;
}