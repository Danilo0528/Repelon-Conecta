import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin } from "lucide-react";
import { Abierto } from "@/components/Chrome";
import { MapaNegocios } from "@/components/MapaNegocios";
import { Button } from "@/components/ui/button";
import { negocioImg } from "@/lib/images";
import { CommercePhoto } from "@/lib/photos";
import type { NegocioListItem } from "@/lib/queries";
import { cn } from "@/lib/utils";

export function MapaPueblo({ negocios }: { negocios: NegocioListItem[] }) {
  const [selId, setSelId] = useState<string | null>(null);
  const sel = negocios.find((n) => n.id === selId) ?? null;
  const puntos = negocios.map((n) => ({ id: n.id, nombre: n.nombre, latitud: n.latitud, longitud: n.longitud, abierto: n.abierto, icono: n.categorias?.icono ?? null }));

  return (
    <div className="glass shadow-float relative overflow-hidden rounded-[28px] p-2">
      <div className="relative overflow-hidden rounded-[22px]">
        <MapaNegocios puntos={puntos} seleccionadoId={selId} onSeleccionar={setSelId} className="h-[460px] w-full md:h-[520px]" />

        <div className="glass-soft pointer-events-none absolute left-4 top-4 z-[500] flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold text-ink">
          <MapPin className="size-3.5 text-leaf" /> Repelón, Atlántico
        </div>

        <div className="absolute inset-x-3 bottom-3 z-[500] md:inset-x-auto md:bottom-auto md:left-4 md:top-14 md:w-80">
          {sel ? (
            <div className="glass rounded-2xl p-3">
              <div className="flex gap-3">
                <CommercePhoto value={sel.imagen_url} fallback={negocioImg(null, sel.categorias?.slug)} alt={sel.nombre} className="size-20 shrink-0 rounded-xl object-cover" />
                <div className="min-w-0">
                  <Abierto abierto={sel.abierto} />
                  <p className="mt-1 truncate font-display font-semibold text-ink">{sel.nombre}</p>
                  <p className="truncate text-xs text-muted-foreground">{sel.direccion}{sel.barrio ? ` · ${sel.barrio}` : ""}</p>
                </div>
              </div>
              <div className="mt-3 flex gap-2">
                <Button asChild size="sm" className="flex-1">
                  <Link to="/negocios/$slug" params={{ slug: sel.slug }}>Ver productos</Link>
                </Button>
                {sel.latitud != null && (
                  <Button asChild size="sm" variant="glass">
                    <a href={`https://www.google.com/maps/dir/?api=1&destination=${sel.latitud},${sel.longitud}`} target="_blank" rel="noreferrer">Cómo llegar</a>
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="glass flex gap-2 overflow-x-auto rounded-2xl p-2 md:flex-col md:overflow-visible">
              {negocios.slice(0, 6).map((n) => (
                <button
                  key={n.id}
                  onClick={() => setSelId(n.id)}
                  className={cn("flex shrink-0 items-center gap-2 rounded-xl p-1.5 pr-3 text-left hover:bg-glass/70")}
                >
                  <span className={cn("size-2.5 rounded-full", n.abierto ? "bg-leaf" : "bg-muted-foreground")} />
                  <span className="text-xs font-semibold text-ink">{n.nombre}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
