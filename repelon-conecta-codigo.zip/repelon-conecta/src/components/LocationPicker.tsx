import { useEffect, useRef } from "react";
import "leaflet/dist/leaflet.css";
import type { Map, Marker } from "leaflet";

export function LocationPicker({ latitude, longitude, onChange }: { latitude: number | null; longitude: number | null; onChange: (lat: number, lng: number) => void }) {
  const node = useRef<HTMLDivElement>(null);
  const callback = useRef(onChange);
  callback.current = onChange;
  const marker = useRef<Marker | null>(null);
  const map = useRef<Map | null>(null);
  useEffect(() => {
    let cancelled = false;
    import("leaflet").then((module) => {
      if (cancelled || !node.current) return;
      const L = module.default ?? module;
      const center: [number, number] = latitude != null && longitude != null ? [latitude, longitude] : [10.4948, -75.1245];
      const instance = L.map(node.current, { scrollWheelZoom: false }).setView(center, 15);
      map.current = instance;
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap", maxZoom: 19 }).addTo(instance);
      if (latitude != null && longitude != null) marker.current = L.marker(center).addTo(instance);
      instance.on("click", (event: import("leaflet").LeafletMouseEvent) => {
        marker.current?.remove();
        marker.current = L.marker(event.latlng).addTo(instance);
        callback.current(event.latlng.lat, event.latlng.lng);
      });
    });
    return () => { cancelled = true; map.current?.remove(); map.current = null; marker.current = null; };
  }, []);
  return <div ref={node} className="h-64 w-full overflow-hidden rounded-lg" aria-label="Selecciona la ubicación del negocio en el mapa" />;
}