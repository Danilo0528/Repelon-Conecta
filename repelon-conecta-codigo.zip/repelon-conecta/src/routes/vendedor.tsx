import type { Tables } from "@/integrations/supabase/types";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { PhotoPicker } from "@/components/PhotoPicker";
import { LocationPicker } from "@/components/LocationPicker";
import { PageTitle } from "@/components/Chrome";
import { RequireAuth } from "@/components/RequireAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cop, estado, PAGOS, slugify } from "@/lib/format";
import { categoriasQuery } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/vendedor")({
  head: () => ({
    meta: [
      { title: "Mi negocio — Repelón Conecta" },
      { name: "description", content: "Publica tu negocio y administra tus productos para que tus vecinos puedan contactarte." },
      { property: "og:title", content: "Vende en Repelón Conecta" },
      { property: "og:description", content: "Muestra tu negocio y productos a los vecinos de Repelón." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAuth mensaje="Entra para crear o administrar tu negocio.">
      <Vendedor />
    </RequireAuth>
  ),
});

function Vendedor() {
  const { user } = useAuth();
  const { data: negocio, isLoading } = useQuery({
    queryKey: ["mi-negocio", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("negocios").select("*").eq("owner_id", user!.id).maybeSingle();
      return data;
    },
  });
  if (isLoading) return <div className="mx-auto max-w-5xl px-4 py-10"><div className="glass h-60 animate-pulse rounded-3xl" /></div>;
  if (!negocio) return <CrearNegocio />;
  return (
    <section className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <PageTitle title={negocio.nombre} subtitle="Panel de tu negocio" />
        <Button asChild variant="glass"><Link to="/negocios/$slug" params={{ slug: negocio.slug }}>Ver mi tienda</Link></Button>
      </div>
      <Tabs defaultValue="productos">
        <TabsList className="glass-soft mb-5 h-auto rounded-2xl p-1">
          <TabsTrigger value="pedidos" className="rounded-xl px-4 py-2">Pedidos anteriores</TabsTrigger>
          <TabsTrigger value="productos" className="rounded-xl px-4 py-2">Productos</TabsTrigger>
          <TabsTrigger value="datos" className="rounded-xl px-4 py-2">Datos</TabsTrigger>
        </TabsList>
        <TabsContent value="pedidos"><PedidosVendedor negocioId={negocio.id} /></TabsContent>
        <TabsContent value="productos"><Productos negocioId={negocio.id} /></TabsContent>
        <TabsContent value="datos"><DatosNegocio negocio={negocio} /></TabsContent>
      </Tabs>
    </section>
  );
}

type NegocioForm = { nombre: string; descripcion: string; direccion: string; barrio: string; whatsapp: string; horario: string; categoria_id: string; latitud: number | null; longitud: number | null };

function NegocioFields({ f, setF }: { f: NegocioForm; setF: (f: NegocioForm) => void }) {
  const { data: categorias } = useQuery(categoriasQuery);
  const set = (k: keyof NegocioForm) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      <div><Label>Nombre del negocio</Label><Input required value={f.nombre} onChange={set("nombre")} className="mt-1 bg-glass/70" /></div>
      <div>
        <Label>Categoría</Label>
        <select value={f.categoria_id} onChange={set("categoria_id")} className="mt-1 h-9 w-full rounded-md border border-input bg-glass/70 px-3 text-sm">
          <option value="">Elige una</option>
          {categorias?.map((c) => <option key={c.id} value={c.id}>{c.icono} {c.nombre}</option>)}
        </select>
      </div>
      <div className="sm:col-span-2"><Label>Descripción</Label><Textarea value={f.descripcion} onChange={set("descripcion")} className="mt-1 bg-glass/70" /></div>
      <div><Label>Dirección</Label><Input required value={f.direccion} onChange={set("direccion")} className="mt-1 bg-glass/70" /></div>
      <div><Label>Barrio o vereda</Label><Input value={f.barrio} onChange={set("barrio")} className="mt-1 bg-glass/70" /></div>
      <div><Label>WhatsApp (con 57)</Label><Input value={f.whatsapp} onChange={set("whatsapp")} placeholder="573001234567" className="mt-1 bg-glass/70" /></div>
      <div><Label>Horario</Label><Input value={f.horario} onChange={set("horario")} placeholder="7:00 a.m. – 7:00 p.m." className="mt-1 bg-glass/70" /></div>
      <div className="sm:col-span-2"><Label>Ubicación del negocio</Label><p className="mb-2 text-sm text-muted-foreground">Toca el mapa para marcar tu local.</p><LocationPicker latitude={f.latitud} longitude={f.longitud} onChange={(latitud, longitud) => setF({ ...f, latitud, longitud })} /></div>
    </div>
  );
}

function CrearNegocio() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [f, setF] = useState<NegocioForm>({ nombre: "", descripcion: "", direccion: "", barrio: "", whatsapp: "", horario: "", categoria_id: "", latitud: null, longitud: null });
  async function crear(e: React.FormEvent) {
    e.preventDefault();
    const slug = `${slugify(f.nombre)}-${Math.random().toString(36).slice(2, 6)}`;
    const { error } = await supabase.from("negocios").insert({ ...f, categoria_id: f.categoria_id || null, owner_id: user!.id, slug });
    if (error) return void toast.error(error.message);
    toast.success("¡Tu negocio ya está en Repelón Conecta!");
    qc.invalidateQueries();
  }
  return (
    <section className="mx-auto max-w-3xl px-4 py-10">
      <PageTitle title="Registra tu negocio" subtitle="Gratis. Muestra tus productos y recibe consultas de tus vecinos." />
      <form onSubmit={crear} className="glass space-y-5 rounded-3xl p-6">
        <NegocioFields f={f} setF={setF} />
        <Button type="submit" size="lg">Crear mi tienda</Button>
      </form>
    </section>
  );
}

type NegocioRow = Tables<"negocios">;

export function DatosNegocio({ negocio }: { negocio: NegocioRow }) {
  const qc = useQueryClient();
  const [f, setF] = useState<NegocioForm>({
    nombre: negocio.nombre, descripcion: negocio.descripcion ?? "", direccion: negocio.direccion, barrio: negocio.barrio ?? "",
    whatsapp: negocio.whatsapp ?? "", horario: negocio.horario ?? "", categoria_id: negocio.categoria_id ?? "", latitud: negocio.latitud, longitud: negocio.longitud,
  });
  const [abierto, setAbierto] = useState(negocio.abierto);
  const [imagen, setImagen] = useState(negocio.imagen_url);
  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("negocios").update({ ...f, categoria_id: f.categoria_id || null, abierto, imagen_url: imagen }).eq("id", negocio.id);
    if (error) return void toast.error(error.message);
    toast.success("Datos guardados");
    qc.invalidateQueries();
  }
  return (
    <form onSubmit={guardar} className="glass space-y-5 rounded-3xl p-6">
      <label className="flex items-center gap-3 text-sm font-semibold text-ink">
        <Switch checked={abierto} onCheckedChange={setAbierto} /> {abierto ? "Abierto ahora" : "Cerrado"}
      </label>
      <NegocioFields f={f} setF={setF} />
      <div><Label>Foto del negocio</Label><div className="mt-2"><PhotoPicker negocioId={negocio.id} onUploaded={setImagen} /></div>{imagen?.startsWith("photo:") && <p className="mt-1 text-sm text-leaf">Nueva foto lista para guardar</p>}</div>
      <Button type="submit">Guardar cambios</Button>
    </form>
  );
}

export function Productos({ negocioId }: { negocioId: string }) {
  const qc = useQueryClient();
  const key = ["productos", negocioId];
  const { data } = useQuery({
    queryKey: key,
    queryFn: async () => (await supabase.from("productos").select("*").eq("negocio_id", negocioId).order("created_at")).data ?? [],
  });
  const [nombre, setNombre] = useState("");
  const [precio, setPrecio] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [imagen, setImagen] = useState<string | null>(null);
  const refresh = () => { qc.invalidateQueries({ queryKey: key }); qc.invalidateQueries({ queryKey: ["negocio"] }); qc.invalidateQueries({ queryKey: ["negocios"] }); };

  async function agregar(e: React.FormEvent) {
    e.preventDefault();
    const p = parseInt(precio.replace(/\D/g, ""), 10);
    if (!nombre.trim() || !p) return void toast.error("Escribe nombre y precio");
    const { error } = await supabase.from("productos").insert({ negocio_id: negocioId, nombre, precio: p, descripcion: descripcion || null, imagen_url: imagen });
    if (error) return void toast.error(error.message);
    setNombre(""); setPrecio(""); setDescripcion(""); setImagen(null);
    refresh();
  }
  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_1.4fr]">
      <form onSubmit={agregar} className="glass h-fit space-y-4 rounded-3xl p-6">
        <h2 className="text-lg font-semibold text-ink">Nuevo producto</h2>
        <div><Label>Nombre</Label><Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="mt-1 bg-glass/70" /></div>
        <div><Label>Precio (COP)</Label><Input value={precio} onChange={(e) => setPrecio(e.target.value)} inputMode="numeric" placeholder="4000" className="mt-1 bg-glass/70" /></div>
        <div><Label>Descripción</Label><Input value={descripcion} onChange={(e) => setDescripcion(e.target.value)} className="mt-1 bg-glass/70" /></div>
        <div><Label>Foto del producto</Label><div className="mt-2"><PhotoPicker negocioId={negocioId} onUploaded={setImagen} /></div>{imagen && <span className="text-sm text-leaf">Foto lista</span>}</div>
        <Button type="submit" className="w-full">Agregar producto</Button>
      </form>
      <div className="glass divide-y divide-border/60 rounded-3xl p-2">
        {data?.length === 0 && <p className="p-6 text-sm text-muted-foreground">Aún no tienes productos.</p>}
        {data?.map((p) => (
          <div key={p.id} className="flex items-center gap-3 p-3">
            <div className="flex-1">
              <p className="font-semibold text-ink">{p.nombre}</p>
              <p className="font-display text-sm font-semibold text-leaf">{cop(p.precio)}</p>
            </div>
            <PhotoPicker negocioId={negocioId} label={p.imagen_url ? "Cambiar foto" : "Foto"} onUploaded={async (value) => { const { error } = await supabase.from("productos").update({ imagen_url: value }).eq("id", p.id); if (error) toast.error(error.message); else refresh(); }} />
            <label className="flex items-center gap-2 text-xs text-muted-foreground">
              <Switch checked={p.disponible} onCheckedChange={async (v) => { await supabase.from("productos").update({ disponible: v }).eq("id", p.id); refresh(); }} />
              {p.disponible ? "Disponible" : "Agotado"}
            </label>
            <Button size="icon" variant="ghost" aria-label="Eliminar" onClick={async () => { await supabase.from("productos").delete().eq("id", p.id); refresh(); }}>
              <Trash2 className="text-destructive" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

const FLUJO = ["RECIBIDO", "PREPARANDO", "EN_CAMINO", "ENTREGADO"];

export function PedidosVendedor({ negocioId }: { negocioId: string }) {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["pedidos-negocio", negocioId],
    queryFn: async () =>
      (await supabase.from("pedidos").select("*, pedido_items(*)").eq("negocio_id", negocioId).order("created_at", { ascending: false })).data ?? [],
    refetchInterval: 15000,
  });
  async function cambiar(id: string, estado: string) {
    const { error } = await supabase.from("pedidos").update({ estado }).eq("id", id);
    if (error) return void toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["pedidos-negocio", negocioId] });
  }
  const hoy = (data ?? []).filter((p) => new Date(p.created_at).toDateString() === new Date().toDateString() && p.estado !== "CANCELADO");
  const pendientes = (data ?? []).filter((p) => !["ENTREGADO", "CANCELADO"].includes(p.estado)).length;

  return (
    <div>
      <div className="mb-5 grid gap-4 sm:grid-cols-3">
        {[["Pedidos hoy", hoy.length], ["Ventas hoy", cop(hoy.reduce((a, p) => a + p.total, 0))], ["Pendientes", pendientes]].map(([l, v]) => (
          <div key={l as string} className="glass rounded-3xl p-5">
            <p className="text-xs text-muted-foreground">{l}</p>
            <p className="font-display text-2xl font-semibold text-ink">{v}</p>
          </div>
        ))}
      </div>
      {data?.length === 0 && <p className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">No hay pedidos anteriores.</p>}
      <div className="space-y-4">
        {data?.map((p) => {
          const e = estado(p.estado);
          const idx = FLUJO.indexOf(p.estado);
          const siguiente = idx >= 0 && idx < FLUJO.length - 1 ? FLUJO[idx + 1] : null;
          return (
            <div key={p.id} className="glass rounded-3xl p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-xs text-muted-foreground">#{p.numero} · {new Date(p.created_at).toLocaleString("es-CO", { dateStyle: "short", timeStyle: "short" })}</p>
                  <h3 className="text-lg font-semibold text-ink">{p.nombre} · {p.telefono}</h3>
                </div>
                <span className={cn("rounded-full px-3 py-1 text-xs font-semibold", e.tone)}>{e.label}</span>
              </div>
              <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
                {p.pedido_items.map((i) => <li key={i.id}>{i.cantidad} × {i.nombre} — {cop(i.precio * i.cantidad)}</li>)}
              </ul>
              <p className="mt-2 text-sm text-ink">
                {p.metodo_entrega === "DOMICILIO" ? `Domicilio: ${p.direccion}${p.barrio ? `, ${p.barrio}` : ""} — ${p.referencia}` : "Recoge en tienda"}
              </p>
              <p className="text-xs text-muted-foreground">{PAGOS[p.metodo_pago] ?? p.metodo_pago}{p.notas ? ` · Nota: ${p.notas}` : ""}</p>
              <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-border/60 pt-3">
                <span className="mr-auto font-display text-lg font-semibold text-ink">{cop(p.total)}</span>
                {siguiente && <Button size="sm" onClick={() => cambiar(p.id, siguiente)}>Marcar: {estado(siguiente).label}</Button>}
                {p.estado === "RECIBIDO" && <Button size="sm" variant="ghost" className="text-destructive" onClick={() => cambiar(p.id, "CANCELADO")}>Rechazar</Button>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
