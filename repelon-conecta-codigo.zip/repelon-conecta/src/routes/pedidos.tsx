import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ClipboardList } from "lucide-react";
import { PageTitle } from "@/components/Chrome";
import { RequireAuth } from "@/components/RequireAuth";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cop, estado, PAGOS } from "@/lib/format";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pedidos")({
  head: () => ({
    meta: [
      { title: "Mis pedidos — Repelón Conecta" },
      { name: "description", content: "Consulta tus pedidos anteriores a los comercios de Repelón." },
      { property: "og:title", content: "Mis pedidos — Repelón Conecta" },
      { property: "og:description", content: "Historial de pedidos en Repelón Conecta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAuth mensaje="Entra para ver tus pedidos.">
      <Pedidos />
    </RequireAuth>
  ),
});

function Pedidos() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["mis-pedidos", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("pedidos")
        .select("*, negocios(nombre, slug, whatsapp), pedido_items(*)")
        .eq("comprador_id", user!.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 20000,
  });

  return (
    <section className="mx-auto max-w-3xl px-4 py-10">
      <PageTitle title="Pedidos anteriores" subtitle="Consulta aquí los pedidos hechos antes del cambio a contacto directo." />
      {isLoading && <div className="glass h-40 animate-pulse rounded-3xl" />}
      {data?.length === 0 && (
        <div className="glass rounded-3xl p-10 text-center">
          <ClipboardList className="mx-auto size-10 text-leaf" />
          <p className="mt-3 text-muted-foreground">Aún no has hecho pedidos.</p>
          <Button asChild className="mt-5"><Link to="/negocios">Explorar comercios</Link></Button>
        </div>
      )}
      <div className="space-y-4">
        {data?.map((p) => {
          const e = estado(p.estado);
          return (
            <div key={p.id} className="glass rounded-3xl p-5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-xs text-muted-foreground">Pedido #{p.numero} · {new Date(p.created_at).toLocaleString("es-CO", { dateStyle: "medium", timeStyle: "short" })}</p>
                  <h2 className="text-lg font-semibold text-ink">{p.negocios?.nombre}</h2>
                </div>
                <span className={cn("rounded-full px-3 py-1 text-xs font-semibold", e.tone)}>{e.label}</span>
              </div>
              <ul className="mt-3 space-y-1 text-sm text-muted-foreground">
                {p.pedido_items.map((i) => (
                  <li key={i.id} className="flex justify-between"><span>{i.cantidad} × {i.nombre}</span><span>{cop(i.precio * i.cantidad)}</span></li>
                ))}
              </ul>
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-border/60 pt-3 text-sm">
                <span className="text-muted-foreground">{p.metodo_entrega === "DOMICILIO" ? "Domicilio" : "Recoger en tienda"} · {PAGOS[p.metodo_pago] ?? p.metodo_pago}</span>
                <span className="font-display text-lg font-semibold text-ink">{cop(p.total)}</span>
              </div>
              {p.negocios?.whatsapp && (
                <a className="mt-2 inline-block text-sm font-semibold text-leaf hover:underline" target="_blank" rel="noreferrer"
                  href={`https://wa.me/${p.negocios.whatsapp}?text=${encodeURIComponent(`Hola, escribo por mi pedido #${p.numero} de Repelón Conecta`)}`}>
                  Escribir al comercio por WhatsApp
                </a>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
}
