import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search } from "lucide-react";
import { z } from "zod";
import { PageTitle } from "@/components/Chrome";
import { StoreCard } from "@/components/StoreCard";
import { categoriasQuery, negociosQuery } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/negocios/")({
  validateSearch: z.object({ categoria: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Comercios de Repelón — Repelón Conecta" },
      { name: "description", content: "Busca tiendas, panaderías, droguerías, ferreterías, productores y servicios de Repelón." },
      { property: "og:title", content: "Comercios de Repelón" },
      { property: "og:description", content: "Todos los negocios del pueblo en un solo lugar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Negocios,
});

function Negocios() {
  const { categoria } = Route.useSearch();
  const navigate = useNavigate({ from: "/negocios/" });
  const [texto, setTexto] = useState("");
  const { data: categorias } = useQuery(categoriasQuery);
  const { data: negocios, isLoading } = useQuery(negociosQuery);
  const t = texto.trim().toLowerCase();
  const lista = (negocios ?? []).filter(
    (n) =>
      (!categoria || n.categorias?.slug === categoria) &&
      (!t || n.nombre.toLowerCase().includes(t) || (n.descripcion ?? "").toLowerCase().includes(t)),
  );

  return (
    <section className="mx-auto max-w-6xl px-4 py-10">
      <PageTitle title="Comercios del pueblo" subtitle="Encuentra lo que necesitas cerca de tu casa." />
      <div className="glass-soft mb-4 flex items-center gap-2 rounded-2xl px-4 py-3">
        <Search className="size-4 text-muted-foreground" />
        <input
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          placeholder="Buscar panadería, droguería, queso…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>
      <div className="mb-6 flex gap-2 overflow-x-auto pb-1 text-xs font-semibold">
        <button
          onClick={() => navigate({ search: {} })}
          className={cn("shrink-0 rounded-full px-3.5 py-1.5", !categoria ? "bg-leaf text-primary-foreground" : "glass-soft text-muted-foreground")}
        >
          Todos
        </button>
        {(categorias ?? []).map((c) => (
          <button
            key={c.id}
            onClick={() => navigate({ search: { categoria: c.slug } })}
            className={cn(
              "shrink-0 rounded-full px-3.5 py-1.5",
              categoria === c.slug ? "bg-leaf text-primary-foreground" : "glass-soft text-muted-foreground",
            )}
          >
            {c.icono} {c.nombre}
          </button>
        ))}
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {isLoading && Array.from({ length: 6 }).map((_, i) => <div key={i} className="glass h-80 animate-pulse rounded-3xl" />)}
        {lista.map((n) => (
          <StoreCard key={n.id} n={n} />
        ))}
      </div>
      {!isLoading && lista.length === 0 && (
        <p className="glass rounded-3xl p-10 text-center text-sm text-muted-foreground">No encontramos comercios con ese filtro.</p>
      )}
    </section>
  );
}
