import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Clock, MapPin, MessageCircle, ArrowLeft } from "lucide-react";
import { Abierto } from "@/components/Chrome";
import { MapaNegocios } from "@/components/MapaNegocios";
import { Button } from "@/components/ui/button";
import { cop } from "@/lib/format";
import { negocioImg } from "@/lib/images";
import { CommercePhoto } from "@/lib/photos";
import { negocioQuery } from "@/lib/queries";

export const Route = createFileRoute("/negocios/$slug")({
  head: ({ params }) => {
    const name = params.slug.replace(/-/g, " ");
    return {
      meta: [
        { title: `${name} — Repelón Conecta` },
        { name: "description", content: `Mira los productos de ${name} y habla directamente con el comercio en Repelón.` },
        { property: "og:title", content: `${name} — Repelón Conecta` },
        { property: "og:description", content: `Conoce los productos y contacta a ${name}, comercio de Repelón.` },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      ],
    };
  },
  component: NegocioPage,
});

function NegocioPage() {
  const { slug } = Route.useParams();
  const { data: n, isLoading } = useQuery(negocioQuery(slug));

  if (isLoading) return <div className="mx-auto max-w-6xl px-4 py-10"><div className="glass h-96 animate-pulse rounded-3xl" /></div>;
  if (!n)
    return (
      <div className="mx-auto max-w-6xl px-4 py-20 text-center">
        <h1 className="text-3xl font-semibold text-ink">Comercio no encontrado</h1>
        <Button asChild className="mt-6"><Link to="/negocios">Ver comercios</Link></Button>
      </div>
    );

  const productos = [...(n.productos ?? [])].sort((a, b) => Number(b.disponible) - Number(a.disponible));

  return (
    <section className="mx-auto max-w-6xl px-4 py-8">
      <Link to="/negocios" className="mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-leaf">
        <ArrowLeft className="size-4" /> Comercios
      </Link>
      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <div className="glass shadow-float overflow-hidden rounded-[28px] p-2">
            <CommercePhoto value={n.imagen_url} fallback={negocioImg(null, n.categorias?.slug)} alt={n.nombre} className="aspect-[16/10] w-full rounded-[22px] object-cover" />
          </div>
          <div className="glass mt-6 rounded-3xl p-6">
            <div className="flex flex-wrap items-center gap-2">
              <Abierto abierto={n.abierto} />
              {n.categorias && <span className="text-xs font-semibold text-muted-foreground">{n.categorias.nombre}</span>}
            </div>
            <h1 className="mt-3 text-3xl font-semibold tracking-tight text-ink md:text-4xl">{n.nombre}</h1>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{n.descripcion}</p>
            <div className="mt-5 space-y-2 text-sm text-ink">
              <p className="flex items-center gap-2"><MapPin className="size-4 text-leaf" /> {n.direccion}{n.barrio ? ` · ${n.barrio}` : ""}</p>
              {n.horario && <p className="flex items-center gap-2"><Clock className="size-4 text-leaf" /> {n.horario}</p>}
            </div>
            {n.latitud != null && n.longitud != null && (
              <div className="mt-5 overflow-hidden rounded-2xl">
                <MapaNegocios puntos={[{ id: n.id, nombre: n.nombre, latitud: n.latitud, longitud: n.longitud, abierto: n.abierto, icono: n.categorias?.icono ?? null }]} seleccionadoId={n.id} zoom={16} className="h-56 w-full" />
              </div>
            )}
            {n.whatsapp && (
              <Button asChild variant="glass" className="mt-5">
                <a href={`https://wa.me/${n.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noreferrer">
                  <MessageCircle /> Escribir por WhatsApp
                </a>
              </Button>
            )}
          </div>
        </div>

        <div>
          <h2 className="mb-4 text-2xl font-semibold text-ink">Productos</h2>
          <div className="glass divide-y divide-border/60 rounded-3xl p-2">
            {productos.length === 0 && <p className="p-6 text-sm text-muted-foreground">Este comercio aún no ha publicado productos.</p>}
            {productos.map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-3">
                {p.imagen_url && <CommercePhoto value={p.imagen_url} fallback={negocioImg(null, n.categorias?.slug)} alt={p.nombre} className="size-16 shrink-0 rounded-lg object-cover" />}
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-ink">{p.nombre}</p>
                  {p.descripcion && <p className="line-clamp-1 text-xs text-muted-foreground">{p.descripcion}</p>}
                  <p className="mt-0.5 font-display text-base font-semibold text-leaf">{cop(p.precio)}</p>
                </div>
                {p.disponible && n.whatsapp ? (
                  <Button asChild size="sm" variant="ink">
                    <a href={`https://wa.me/${n.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent(`Hola, vi ${p.nombre} en Repelón Conecta. ¿Está disponible?`)}`} target="_blank" rel="noreferrer" aria-label={`Consultar por ${p.nombre} en WhatsApp`}>
                      <MessageCircle /> Consultar
                    </a>
                  </Button>
                ) : !p.disponible ? (
                  <span className="text-sm font-semibold text-muted-foreground">Agotado</span>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
