import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { z } from "zod";
import { Logo } from "@/components/Chrome";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/entrar")({
  validateSearch: z.object({ next: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Entrar — Repelón Conecta" },
      { name: "description", content: "Inicia sesión o crea tu cuenta para publicar tu negocio en Repelón Conecta." },
      { property: "og:title", content: "Entrar — Repelón Conecta" },
      { property: "og:description", content: "Accede a tu cuenta de Repelón Conecta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Entrar,
});

function Entrar() {
  const { next } = Route.useSearch();
  const dest = next && next.startsWith("/") && !next.startsWith("//") ? next : "/";
  const { user } = useAuth();
  const navigate = useNavigate();
  const [modo, setModo] = useState<"in" | "up">("in");
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (user) navigate({ to: dest });
  }, [user, dest, navigate]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    if (modo === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
      if (error) toast.error("Correo o contraseña incorrectos");
    } else {
      const { error } = await supabase.auth.signUp({
        email,
        password: pass,
        options: { data: { nombre }, emailRedirectTo: window.location.origin + dest },
      });
      if (error) toast.error(error.message);
      else toast.success("Revisa tu correo para confirmar la cuenta.");
    }
    setBusy(false);
  }

  async function google() {
    const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/entrar" + (next ? `?next=${encodeURIComponent(dest)}` : "") });
    if (r.error) toast.error("No se pudo entrar con Google");
  }

  return (
    <section className="mx-auto max-w-md px-4 py-14">
      <div className="glass rounded-3xl p-8">
        <Logo />
        <h1 className="mt-6 text-2xl font-semibold text-ink">{modo === "in" ? "Bienvenido de vuelta" : "Crea tu cuenta"}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Para publicar y administrar tu negocio.</p>
        <Button variant="glass" className="mt-6 w-full" onClick={google}>Continuar con Google</Button>
        <div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><div className="h-px flex-1 bg-border" />o<div className="h-px flex-1 bg-border" /></div>
        <form onSubmit={submit} className="space-y-4">
          {modo === "up" && (
            <div><Label>Nombre</Label><Input required value={nombre} onChange={(e) => setNombre(e.target.value)} className="mt-1 bg-glass/70" /></div>
          )}
          <div><Label>Correo</Label><Input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 bg-glass/70" /></div>
          <div><Label>Contraseña</Label><Input required type="password" minLength={6} value={pass} onChange={(e) => setPass(e.target.value)} className="mt-1 bg-glass/70" /></div>
          <Button type="submit" className="w-full" disabled={busy}>{modo === "in" ? "Entrar" : "Crear cuenta"}</Button>
        </form>
        <button onClick={() => setModo(modo === "in" ? "up" : "in")} className="mt-5 w-full text-center text-sm text-leaf hover:underline">
          {modo === "in" ? "¿No tienes cuenta? Regístrate" : "¿Ya tienes cuenta? Entra"}
        </button>
      </div>
    </section>
  );
}
