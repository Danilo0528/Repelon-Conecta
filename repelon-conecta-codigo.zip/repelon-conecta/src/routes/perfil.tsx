import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageTitle } from "@/components/Chrome";
import { RequireAuth } from "@/components/RequireAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Mi perfil — Repelón Conecta" },
      { name: "description", content: "Tus datos de contacto en Repelón Conecta." },
      { property: "og:title", content: "Mi perfil — Repelón Conecta" },
      { property: "og:description", content: "Administra tu cuenta de Repelón Conecta." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAuth mensaje="Entra para ver tu perfil.">
      <Perfil />
    </RequireAuth>
  ),
});

function Perfil() {
  const { user, signOut } = useAuth();
  const { data: isAdmin } = useQuery({ queryKey: ["admin-nav", user?.id], enabled: Boolean(user), queryFn: async () => { const { data } = await supabase.from("user_roles").select("role").eq("user_id", user?.id ?? "").eq("role", "admin").maybeSingle(); return data?.role === "admin"; } });
  const [nombre, setNombre] = useState("");
  const [telefono, setTelefono] = useState("");
  useEffect(() => {
    supabase.from("profiles").select("*").eq("id", user!.id).maybeSingle().then(({ data }) => {
      setNombre(data?.nombre ?? "");
      setTelefono(data?.telefono ?? "");
    });
  }, [user]);

  async function guardar(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("profiles").upsert({ id: user!.id, nombre, telefono });
    if (error) toast.error(error.message);
    else toast.success("Perfil guardado");
  }

  return (
    <section className="mx-auto max-w-md px-4 py-10">
      <PageTitle title="Mi perfil" subtitle={user?.email ?? undefined} />
      <form onSubmit={guardar} className="glass space-y-4 rounded-3xl p-6">
        <div><Label>Nombre</Label><Input value={nombre} onChange={(e) => setNombre(e.target.value)} className="mt-1 bg-glass/70" /></div>
        <div><Label>Teléfono</Label><Input value={telefono} onChange={(e) => setTelefono(e.target.value)} inputMode="tel" className="mt-1 bg-glass/70" /></div>
        <Button type="submit" className="w-full">Guardar</Button>
      </form>
      <div className="mt-4 grid gap-3">
        <Button asChild variant="glass"><Link to="/vendedor">Mi negocio</Link></Button>
        {isAdmin && <Button asChild variant="glass"><Link to="/admin">Administración</Link></Button>}
        <Button variant="ghost" onClick={signOut}>Cerrar sesión</Button>
      </div>
    </section>
  );
}
