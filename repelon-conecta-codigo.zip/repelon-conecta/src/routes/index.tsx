import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Store, Smartphone, Bike, Search } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Button } from "@/components/ui/button";
import { StoreCard } from "@/components/StoreCard";
import { MapaPueblo } from "@/components/MapaPueblo";
import { categoriasQuery, negociosQuery } from "@/lib/queries";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Repelón Conecta — Todo el pueblo a un toque de tu celular" },
      { name: "description", content: "Descubre panaderías, tiendas, droguerías, ferreterías y productores de Repelón. Consulta sus productos y habla con ellos directamente." },
      { property: "og:title", content: "Repelón Conecta — Todo el pueblo a un toque" },
      { property: "og:description", content: "Encuentra comercios y productos de Repelón y contacta directamente a cada negocio." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  const { data: categorias } = useQuery(categoriasQuery);
  const { data: negocios, isLoading } = useQuery(negociosQuery);
  const [soloAbiertos, setSoloAbiertos] = useState(false);
  const [busqueda, setBusqueda] = useState("");
  const term = busqueda.trim().toLocaleLowerCase("es");
  const lista = (negocios ?? []).filter((n) => (!soloAbiertos || n.abierto) && (!term || [n.nombre, n.descripcion, n.barrio, ...(n.productos ?? []).map((p) => p.nombre)].some((v) => v?.toLocaleLowerCase("es").includes(term))));

  return (
    <>
      <section className="mx-auto max-w-6xl px-4 pb-6 pt-10 md:pt-16">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div>
            <span className="glass-soft inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold text-leaf">
              <span className="size-2 rounded-full bg-leaf" /> Comercio local, digitalizado
            </span>
            <h1 className="mt-5 text-4xl font-semibold leading-[1.05] tracking-tight text-ink md:text-6xl">
              Todo el pueblo, <span className="italic text-leaf">a un toque</span> de tu celular.
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-muted-foreground">
              Descubre las panaderías, ferreterías, droguerías y productores de Repelón.
              Consulta sus productos y habla directamente con tus vecinos.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/negocios">Explorar comercios</Link>
              </Button>
              <Button asChild size="lg" variant="glass">
                <Link to="/vendedor">Registrar mi negocio</Link>
              </Button>
            </div>
            <div className="mt-8 flex flex-wrap gap-2 text-xs font-medium">
              {(categorias ?? []).slice(0, 6).map((c) => (
                <Link
                  key={c.id}
                  to="/negocios"
                  search={{ categoria: c.slug }}
                  className="glass-soft rounded-full px-3 py-1.5 text-muted-foreground hover:text-leaf"
                >
                  {c.icono} {c.nombre}
                </Link>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="glass shadow-float overflow-hidden rounded-[28px] p-2">
              <img src={hero} alt="Mostrador de una tienda del pueblo con pan y frutas" width={1200} height={1008} className="aspect-[6/5] w-full rounded-[22px] object-cover" />
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pt-14">
        <div className="mb-5">
          <h2 className="text-2xl font-semibold text-ink md:text-3xl">El pueblo en el mapa</h2>
          <p className="mt-1 text-sm text-muted-foreground">Toca un pin para ver el comercio y cómo llegar.</p>
        </div>
        <MapaPueblo negocios={negocios ?? []} />
      </section>

      <section className="mx-auto max-w-6xl px-4 py-10">
        <label className="glass-soft mb-6 flex items-center gap-3 rounded-lg px-4 py-3 text-ink"><Search className="size-5 text-leaf" /><span className="sr-only">Buscar comercios y productos</span><input value={busqueda} onChange={(e) => setBusqueda(e.target.value)} placeholder="Busca un comercio o producto" className="w-full bg-transparent text-base outline-none placeholder:text-muted-foreground" /></label>
        <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <h2 className="text-2xl font-semibold text-ink md:text-3xl">Comercios del pueblo</h2>
          <div className="flex gap-2 text-xs font-semibold">
            {[
              [false, "Todos"],
              [true, "Abiertos ahora"],
            ].map(([v, l]) => (
              <button
                key={String(l)}
                onClick={() => setSoloAbiertos(v as boolean)}
                className={cn(
                  "rounded-full px-3 py-1.5",
                  soloAbiertos === v ? "bg-leaf text-primary-foreground" : "glass-soft text-muted-foreground",
                )}
              >
                {l as string}
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {isLoading &&
            Array.from({ length: 3 }).map((_, i) => <div key={i} className="glass h-80 animate-pulse rounded-3xl" />)}
          {lista.map((n) => (
            <StoreCard key={n.id} n={n} />
          ))}
        </div>
        {!isLoading && lista.length === 0 && <p className="py-8 text-center text-muted-foreground">No encontramos resultados.</p>}
        <div className="mt-6 text-center">
          <Button asChild variant="glass">
            <Link to="/negocios">Ver todos los comercios</Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-6">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { Icon: Store, t: "Publica tu negocio", d: "Muestra tus productos, precios y fotos a los vecinos.", c: "bg-leaf/10 text-leaf" },
            { Icon: Smartphone, t: "Habla directamente", d: "Los vecinos pueden consultarte por WhatsApp desde cada producto.", c: "bg-azul/10 text-azul" },
            { Icon: Bike, t: "Encuentra comercios cercanos", d: "Consulta el mapa para saber dónde queda cada negocio.", c: "bg-cielo/20 text-azul" },
          ].map(({ Icon, t, d, c }) => (
            <div key={t} className="glass rounded-3xl p-6">
              <div className={cn("grid size-11 place-items-center rounded-2xl", c)}>
                <Icon className="size-5" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-ink">{t}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>

        <div className="glass mt-8 flex flex-col items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-leaf/10 via-glass/40 to-azul/10 p-6 md:flex-row">
          <div>
            <h3 className="text-xl font-semibold text-ink">¿Tienes un negocio en Repelón?</h3>
            <p className="text-sm text-muted-foreground">Muestra tus productos a todo el pueblo.</p>
          </div>
          <Button asChild size="lg">
            <Link to="/vendedor">Crear mi tienda gratis</Link>
          </Button>
        </div>
      </section>
    </>
  );
}
