import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { PageTitle } from "@/components/Chrome";
import { RequireAuth } from "@/components/RequireAuth";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { cop, estado } from "@/lib/format";
import { DatosNegocio, Productos, PedidosVendedor } from "@/routes/vendedor";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [
    { title: "Administración — Repelón Conecta" },
    { name: "description", content: "Gestión de comercios, productos y pedidos anteriores de Repelón Conecta." },
    { property: "og:title", content: "Administración — Repelón Conecta" },
    { property: "og:description", content: "Panel de gestión del comercio local de Repelón." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <RequireAuth mensaje="Entra para administrar los comercios."><Admin /></RequireAuth>,
});

function Admin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [selected, setSelected] = useState("");
  const [tab, setTab] = useState("negocios");
  const { data: role, isLoading: checking } = useQuery({
    queryKey: ["admin-role", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase.from("user_roles").select("role").eq("user_id", user?.id ?? "").eq("role", "admin").maybeSingle();
      if (error) throw error;
      return data;
    },
  });
  const isAdmin = role?.role === "admin";
  const { data: negocios } = useQuery({
    queryKey: ["admin-negocios"], enabled: isAdmin,
    queryFn: async () => { const { data, error } = await supabase.from("negocios").select("*").order("nombre"); if (error) throw error; return data; },
  });
  const { data: pedidos } = useQuery({
    queryKey: ["admin-pedidos"], enabled: isAdmin,
    queryFn: async () => { const { data, error } = await supabase.from("pedidos").select("id, numero, nombre, estado, total, negocio_id, created_at, negocios(nombre)").order("created_at", { ascending: false }).limit(100); if (error) throw error; return data; },
  });
  if (checking) return <section className="mx-auto max-w-5xl px-4 py-10">Verificando acceso…</section>;
  if (!isAdmin) return <section className="mx-auto max-w-5xl px-4 py-10"><PageTitle title="Acceso restringido" subtitle="Esta sección es para administradores autorizados." /><Button asChild><Link to="/">Volver al inicio</Link></Button></section>;
  const negocio = negocios?.find((n) => n.id === selected) ?? negocios?.[0];
  return <section className="mx-auto max-w-6xl px-4 py-10">
    <PageTitle title="Administración" subtitle="Comercios y productos del pueblo" />
    <Tabs value={tab} onValueChange={setTab}>
      <TabsList className="mb-6 h-auto flex-wrap"><TabsTrigger value="negocios">Comercios</TabsTrigger><TabsTrigger value="pedidos">Pedidos anteriores</TabsTrigger></TabsList>
      <TabsContent value="negocios">
        <div className="mb-5"><Label htmlFor="admin-store">Comercio</Label><select id="admin-store" value={negocio?.id ?? ""} onChange={(e) => setSelected(e.target.value)} className="mt-1 h-11 w-full max-w-md rounded-lg border border-input bg-background px-3 text-base text-ink">{negocios?.map((n) => <option key={n.id} value={n.id}>{n.nombre}</option>)}</select></div>
        {negocio && <div key={negocio.id} className="space-y-8">
          <div className="flex flex-wrap items-center gap-4 border-b border-border pb-5"><div className="flex-1"><h2 className="text-xl font-semibold text-ink">{negocio.nombre}</h2><p className="text-sm text-muted-foreground">{negocio.direccion}</p></div><label className="flex items-center gap-2 text-sm text-ink"><Switch checked={negocio.destacado} onCheckedChange={async (v) => { const { error } = await supabase.from("negocios").update({ destacado: v }).eq("id", negocio.id); if (error) toast.error(error.message); else { qc.invalidateQueries({ queryKey: ["admin-negocios"] }); qc.invalidateQueries({ queryKey: ["negocios"] }); } }} /> Destacado</label></div>
          <div><h3 className="mb-4 text-xl font-semibold text-ink">Datos y ubicación</h3><DatosNegocio key={negocio.id} negocio={negocio} /></div>
          <div><h3 className="mb-4 text-xl font-semibold text-ink">Productos y fotos</h3><Productos negocioId={negocio.id} /></div>
          <div><h3 className="mb-4 text-xl font-semibold text-ink">Pedidos anteriores del comercio</h3><PedidosVendedor negocioId={negocio.id} /></div>
        </div>}
      </TabsContent>
      <TabsContent value="pedidos"><div className="divide-y divide-border">{pedidos?.map((p) => <div key={p.id} className="flex flex-wrap items-center gap-3 py-4"><div className="min-w-48 flex-1"><p className="font-semibold text-ink">#{p.numero} · {p.negocios?.nombre}</p><p className="text-sm text-muted-foreground">{p.nombre} · {new Date(p.created_at).toLocaleDateString("es-CO")}</p></div><span className="text-sm text-ink">{estado(p.estado).label}</span><strong className="text-ink">{cop(p.total)}</strong><Button variant="glass" onClick={() => { setSelected(p.negocio_id); setTab("negocios"); }}>Ver comercio</Button></div>)}</div></TabsContent>
    </Tabs>
  </section>;
}